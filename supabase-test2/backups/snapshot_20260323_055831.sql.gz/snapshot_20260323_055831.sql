--
-- PostgreSQL database dump
--

\restrict LczvTg0jEb1kHvVk1BIgcdsMcOMyPMNTvijIKT2f6VDIHMoR3htab8cm7Om81fD

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: ram
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    user_id integer,
    product_id integer,
    quantity integer,
    ordered_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.orders OWNER TO ram;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: ram
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO ram;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ram
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: ram
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name text NOT NULL,
    price numeric(10,2),
    stock integer DEFAULT 0
);


ALTER TABLE public.products OWNER TO ram;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: ram
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO ram;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ram
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: ram
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO ram;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: ram
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO ram;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ram
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: ram
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: ram
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: ram
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: ram
--

COPY public.orders (id, user_id, product_id, quantity, ordered_at) FROM stdin;
1	1	2	3	2026-03-23 05:48:38.359834+00
2	2	1	1	2026-03-23 05:48:38.359834+00
3	3	3	10	2026-03-23 05:48:38.359834+00
4	4	2	2	2026-03-23 05:48:38.359834+00
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: ram
--

COPY public.products (id, name, price, stock) FROM stdin;
1	Widget Pro	299.99	50
2	Gadget Lite	99.50	200
3	Thingamajig	19.99	1000
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ram
--

COPY public.users (id, name, email, created_at) FROM stdin;
1	Ram	ram@example.com	2026-03-23 05:48:38.346629+00
2	Sita	sita@example.com	2026-03-23 05:48:38.346629+00
3	Krishna	krishna@example.com	2026-03-23 05:48:38.346629+00
4	Arjun	arjun@example.com	2026-03-23 05:48:38.346629+00
5	Lakshman	lakshman@example.com	2026-03-23 05:48:38.346629+00
\.


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ram
--

SELECT pg_catalog.setval('public.orders_id_seq', 4, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ram
--

SELECT pg_catalog.setval('public.products_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ram
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: ram
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: ram
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: ram
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ram
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: orders orders_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ram
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ram
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict LczvTg0jEb1kHvVk1BIgcdsMcOMyPMNTvijIKT2f6VDIHMoR3htab8cm7Om81fD

